# Frame Function Mobile v0.3.2

- V-Slice / Polymod API 0.8.7.
- Four-second black title card: `FRAME FUNCTION`, centered, with fade in/out.
- The first countdown event is canceled and restarted after the 4-second intro, so the normal countdown and falling notes do not begin behind the title card.
- Silent black-hole background video: H.264, 640x360, 20 FPS, 173.8 seconds (matched to Overflow instrumental).
- Video starts at song start to stay synchronized with the instrumental.
- Video/fallback layer uses zIndex 40: above the stock `mainStage` props (zIndex 10/20/30) and below GF/BF/opponent characters (zIndex 100/200/300).
- Includes `images/overflow-bg-fallback.png`; shown if hxvlc/video playback is unavailable on the Android build.
- Preserves the existing chart, HUD, note style and Hold assets.

## Android note

Video playback requires the installed V-Slice build to include `FEATURE_VIDEO_PLAYBACK` / hxvlc. If it does not, the still black-hole frame is shown as a fallback.

## Installation

1. Back up the existing `frame-function` folder.
2. Replace it with the `frame-function` folder from this ZIP.
3. Keep the Note Color Editor as its separate mod.
4. Restart the game and test `Overflow`.

## Validation performed

- ZIP CRC and file list checked.
- JSON metadata parsed.
- MP4 stream checked: H.264, 640x360, 20 FPS, no audio, 173.8 s.
- Countdown deferral uses the documented V-Slice `COUNTDOWN_START` cancellation and `PlayState.startCountdown()` restart flow.
- HScript and video playback were not run in the Android game; device testing is still required.
