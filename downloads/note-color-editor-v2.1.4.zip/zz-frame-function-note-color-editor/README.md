# Frame Function Note Color Editor — Standalone Menu

Target: Frame Function Mobile, V-Slice / Polymod API 0.8.7.

## What this build changes

This replaces the old Preferences-per-slider layout with a dedicated full-screen editor, inspired by Psych Engine's Note Color Editor:

- A single `NOTE COLOR EDITOR >` touch-friendly entry appears at the bottom of Options.
- Four selectable directions: LEFT, DOWN, UP, RIGHT.
- One selected direction at a time, with a live color preview.
- Hue, Saturation and Brightness sliders; drag with touch/mouse.
- Quick color presets: White, Gray, Red, Orange, Yellow, Green, Cyan, Blue, Purple and Pink.
- Values are saved through `Save.setModOptions` and persist between sessions.
- The original note, receptor, sustain and hold-cover assets are not replaced. Existing sprites are tinted in-place by the module.
- The existing Hold / Hold Cover construction path and sustain timing are untouched.

## Install

1. Extract the ZIP.
2. Copy `zz-frame-function-note-color-editor` into the game's `mods` folder.
3. Keep Frame Function installed and enabled.
4. Enable this editor mod as well.
5. Restart the game, open **Options**, and tap **NOTE COLOR EDITOR** at the bottom.

## Controls

- Tap one of the four lane panels to choose a direction.
- Drag a slider to adjust Hue, Saturation or Brightness.
- Tap a preset to apply it to the selected direction.
- Tap the visible **< BACK** button at the bottom-left to return to Options.
- On keyboard: Left/Right changes direction, Up/Down changes selected channel, A/D adjusts the selected channel, Escape/Backspace returns to Options.
- Changes save automatically.

## Fixes in 2.0.1

- Removed the unsupported `StringTools.hex()` call from the scripted state. RGB hex display is now formatted locally.
- Added `FlxG.touches.list` handling alongside mouse input. The Options entry, lane tabs, preset buttons, and HSV sliders now respond to Android touch.
- Slider dragging follows the pointer that started the drag and stops when that pointer is released.

## Compatibility / test status

The package targets the same V-Slice 0.8.7 HScript module and scripted-state layout used by the supplied project. It does not modify note-style JSON or Hold assets. The ZIP and metadata are validated locally and the HaxeFlixel touch API usage was checked against the FlxTouch / FlxPointer API documentation. This environment cannot launch Frame Function Mobile, so the final Android runtime behavior still needs device testing.

## Fix in 2.0.2

- Added a visible, touch-enabled **< BACK** button in the editor. It returns directly to Options; Android Back / Escape remain supported as alternate ways to leave.


## Runtime color bridge fix in 2.1.0

- Removed the `currentChart.noteStyle == "circle"` early return. The saved colors now apply to the active chart's selected note style rather than silently skipping charts with another style ID.
- Reloads the latest `Save.getModOptions()` values during gameplay so the module does not keep a stale options object after the editor saves changes on mobile.
- Applies the per-direction tint to the documented V-Slice `StrumlineNote.direction`, `NoteSprite.direction`, and `SustainTrail.noteDirection` fields.
- Applies the matching tint to each `NoteHoldCover.glow` and its child sprites. Hold creation, sustain timing, and cover animation logic remain untouched.
- Runtime verification on the Play Store Android build is still required; this package was statically inspected and ZIP-validated, not launched in the game.


## Runtime bridge correction in 2.1.1

- Replaced reflective lookup of gameplay sprite groups and direction properties with direct typed access to V-Slice `Strumline` fields: `strumlineNotes`, `notes`, `holdNotes`, and `noteHoldCovers`.
- Applies tint directly to `StrumlineNote.color`, `NoteSprite.color`, `SustainTrail.color`, and `NoteHoldCover.glow` / child sprites.
- Both player and opponent strumlines are processed.
- SustainTrail tint uses the inherited sprite color transform, which is passed to V-Slice's `drawTriangles()` renderer; hold construction and clipping are unchanged.
- This is a static code correction based on the V-Slice source API. Android runtime testing is still required.


## Performance optimization in 2.1.2

- Removed the full note/receptor/hold traversal from every render frame.
- Precomputes the four lane colors when saved preferences change.
- Polls saved options twice per second instead of every frame.
- Updates static receptors only when colors or Strumline instances change.
- Discovers newly spawned notes, sustain trails and hold covers at 10 Hz.
- Checks the existing tint before assigning it, avoiding needless sprite dirty/render updates.
- Keeps the original Hold and Hold Cover creation/animation code untouched.

Static validation only: the ZIP and HScript source were inspected and packaged. Android FPS/runtime testing is still required.


## Micro-stutter reduction in 2.1.4

- Removed periodic `Save.getModOptions()` polling during gameplay. Preferences are reloaded once when entering `PlayState`, after the editor has saved them.
- Spread dynamic tint discovery across player and opponent Strumlines on alternating 100 ms intervals, reducing peak work per frame while preserving discovery at 5 Hz per side.
- Skips inactive/invisible pooled notes, sustain trails and hold covers before tint work.
- Keeps cached lane colors and the existing Hold/Hold Cover construction path.

This is a code-level optimization only. It has not been profiled or runtime-tested on the user's Android device; actual FPS improvement must be measured in-game.
